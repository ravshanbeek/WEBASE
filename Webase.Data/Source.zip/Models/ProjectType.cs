﻿using System;
using System.Collections.Generic;

namespace Webase.Data;

public partial class ProjectType
{
    public int Id { get; set; }

    public string? Typename { get; set; }
}
